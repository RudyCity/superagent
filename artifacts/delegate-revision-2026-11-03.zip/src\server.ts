import http from "http";
import crypto from "node:crypto";
import net from "net";
import { URL } from "url";
import fs from "fs";
import path from "path";
import { tryStatSync } from "./core/tools/helpers.js";
import os from "os";
import { Agent } from "./core/agent.js";
import type { AgentEvent } from "./core/agent.js";
import { getConfig, getSettings, getConfiguredProviders, addTrustedDirectory, ensureDirectoryTrusted, getPresets, getActivePresetId, setActivePresetId, updateSettings, listHistorySessions, getTrustedDirectories, closeHistoryDb, generateSessionId, purgeEmptySessions, getPackageRootDir, getInstalledSkills, getSuperAgentVersion, getRootConfigDir } from "./core/config.js";
import { readChecklistTasks, ReadChecklistResult } from "./core/taskChecklist.js";
import { subagentInstances, superagentInstances, backgroundTasks, scheduledJobs, registerMasterAgent, subscribeToActiveOutput, subscribeToSubagents, subscribeToSuperagents, registerQuestionHandler } from "./core/tools/state.js";
import { evaluateCoreDrain } from "./core/runtime/coreDrainInspection.js";
import { setBrowserControlHandler } from "./core/tools/otherTools.js";
import { getBrowserMacros, saveBrowserMacro, deleteBrowserMacro } from "./core/config/browserMacros.js";
import { execSync } from "child_process";
import { handleServerRoute } from "./serverRoutes.js";
import { lockEventEmitter } from "./core/storage/sharedMemory.js";
import { buildCorsHeaders, ensureServerAuthToken, isRequestAuthorized, isPathInsideOrEqual } from "./core/utils/serverSecurity.js";
import { isCanonicalMotionWorkspaceAllowed } from "./core/motion/workspaceAccess.js";
import { shouldDeliverEventToClient } from "./core/utils/sessionEventScope.js";
import { SessionEventReplay } from "./core/utils/sessionEventReplay.js";
import { appendChatEvent, pruneChatRuntimeLedger, recoverInterruptedChatTurns, replayChatEvents } from "./core/utils/chatRuntimeLedger.js";
import { recordAgentTimeline, projectAgentTimelineEnvelope, bindTlineRootAgent } from "./core/channels/tlineAgentTimeline.js";
import { registerTlineApproval } from "./core/channels/tlineApprovalRegistry.js";

// Forward lock events to connected t-line desktop clients
lockEventEmitter.on("tline_bridge_sync", (syncPayload) => {
  broadcastEvent({
    type: "tline_bridge_sync",
    ...syncPayload
  });
});

const SUPERAGENT_SERVER_LOG_FILE = path.join(os.homedir(), ".superagent-r", "superagent-server.log");

export function logToSuperAgentServerFile(message: string) {
  const timestamp = new Date().toISOString();
  const logLine = `[${timestamp}] ${message}\n`;
  try {
    const dir = path.dirname(SUPERAGENT_SERVER_LOG_FILE);
    // 1 syscall instead of 2: `mkdirSync({ recursive: true })` is a
    // no-op when the directory already exists, so we don't need the
    // existsSync guard.
    fs.mkdirSync(dir, { recursive: true });
    // 1 syscall via statSync to check size threshold (skip the read
    // itself — we just need the size from the stat result).
    const logStat = tryStatSync(SUPERAGENT_SERVER_LOG_FILE);
    if (logStat && logStat.size > 5 * 1024 * 1024) {
      fs.writeFileSync(SUPERAGENT_SERVER_LOG_FILE, `[${timestamp}] [INFO] Log file rotated (exceeded 5MB limit)\n`);
    }
    fs.appendFile(SUPERAGENT_SERVER_LOG_FILE, logLine, () => {});
  } catch (err) {
    // Ignore logging errors
  }
}

// Global Process Crash Handlers to prevent silent crashes and log to superagent-server.log
process.on('uncaughtException', (err: Error) => {
  const errStr = `[FATAL CRASH] Uncaught Exception: ${err?.stack || err?.message || String(err)}`;
  console.error(errStr);
  logToSuperAgentServerFile(errStr);
  process.exit(1);
});

process.on('unhandledRejection', (reason: any) => {
  const errStr = `[FATAL ERROR] Unhandled Promise Rejection: ${reason?.stack || reason?.message || String(reason)}`;
  console.error(errStr);
  logToSuperAgentServerFile(errStr);
  process.exit(1);
});

export type ClientMode = "chrome-extension" | "tline";

interface AgentSession {
  agent: Agent;
  workspace: string;
  mode: "single" | "multi";
  clientMode: ClientMode;
  sessionId: string;
  isCliSession: boolean;
  lastActiveTime?: number;
}

let serverDefaultClientMode: ClientMode = "tline";

export function resolveClientMode(
  req: http.IncomingMessage,
  body?: any,
  defaultMode: ClientMode = serverDefaultClientMode
): ClientMode {
  const headerMode = req.headers["x-client-mode"] as string;
  const parsedUrl = new URL(req.url || "", `http://${req.headers.host || "localhost"}`);
  const queryMode = parsedUrl.searchParams.get("clientMode") || parsedUrl.searchParams.get("client_mode");
  const bodyMode = body?.clientMode || body?.client_mode;

  const raw = (bodyMode || headerMode || queryMode || "").toLowerCase();
  if (raw.includes("chrome") || raw.includes("extension") || raw === "ext") {
    return "chrome-extension";
  }
  if (raw.includes("tline") || raw.includes("cli")) {
    return "tline";
  }
  return defaultMode;
}

async function createAgentForMode(
  targetWorkspace: string,
  targetMode: "single" | "multi",
  targetClientMode: ClientMode
): Promise<Agent> {
  let customSystemPrompt: string | undefined = undefined;
  let customTools: any[] | undefined = undefined;

  if (targetClientMode === "chrome-extension") {
    const { CHROME_EXTENSION_SYSTEM_PROMPT } = await import("./core/prompts.js");
    const { chromeExtensionToolset } = await import("./core/tools/toolsets.js");
    customSystemPrompt = CHROME_EXTENSION_SYSTEM_PROMPT;
    // Extension-chat mode: the 12 extension-dependent browser tools STAY ACTIVE
    // here -- this is the only mode where the extension is guaranteed present
    // (the server serves the extension sidepanel chat).
    customTools = chromeExtensionToolset;
  } else {
    // tline mode (SuperAgent CLI / Desktop equivalent): hide the 12
    // extension-dependent browser tools -- the extension is not guaranteed
    // present here. control_chrome_cdp remains as the extension-free path.
    const { filterExtensionChatTools } = await import("./core/tools/toolsets.js");
    if (targetMode === "multi") {
      const { MASTER_AGENT_SYSTEM_PROMPT } = await import("./core/prompts.js");
      const { masterToolset } = await import("./core/tools/toolsets.js");
      customSystemPrompt = MASTER_AGENT_SYSTEM_PROMPT;
      customTools = filterExtensionChatTools(masterToolset);
    } else {
      const { superagentToolset } = await import("./core/tools/toolsets.js");
      customSystemPrompt = undefined;
      customTools = filterExtensionChatTools(superagentToolset);
    }
  }

  // Delegate is a single-agent capability, not a Master orchestration tool.
  if (targetMode === "single" && customTools) {
    const { delegateToolset } = await import("./core/tools/toolsets.js");
    customTools = [...customTools, ...delegateToolset];
  }

  // Discover only tools visible in the actual client mode.
  // T-Line keeps the existing 12 extension-dependent tools hidden.
  if (customTools) {
    const { withModeAwareDiscoveryTools } = await import("./core/tools/toolsets.js");
    customTools = withModeAwareDiscoveryTools(customTools, targetClientMode === "chrome-extension");
  }

  let agent: Agent;
  agent = new Agent(
    (event: AgentEvent) => onEvent(event, agent),
    (toolCall: any, description: string) => onPermission(toolCall, description, agent),
    (question: any, options?: string[], isMultiSelect?: boolean, initialCheckedIndices?: number[], inputType?: string) =>
      onQuestion(question, options, isMultiSelect, initialCheckedIndices, inputType, agent),
    customSystemPrompt,
    customTools,
    targetWorkspace
  );

  if (targetMode === "multi") {
    agent.tier = "master";
    agent.isMultiAgent = true;
    registerMasterAgent(agent);
  } else {
    agent.tier = "single";
  }

  return agent;
}

export const activeSessions = new Map<string, AgentSession>();
let lastActiveWorkspace: string = process.cwd();
let isBrowseDialogOpen = false;
let visionServerProcess: any = null;

export const killVisionServerProcess = () => {
  if (visionServerProcess) {
    try {
      if (process.platform === "win32") {
        try {
          execSync(`taskkill /F /T /PID ${visionServerProcess.pid}`, { stdio: "ignore", windowsHide: true });
        } catch {}
      } else {
        visionServerProcess.kill();
      }
    } catch {}
  }
};

function resolveSession(
  req: http.IncomingMessage,
  requestedSessionId?: string,
  explicitWorkspace?: string
): AgentSession | null {
  const parsedUrl = new URL(req.url || "", `http://${req.headers.host || "localhost"}`);
  let wsPath = explicitWorkspace || (req.headers["x-workspace-path"] as string) || parsedUrl.searchParams.get("workspace") || "";
  const querySessionId = parsedUrl.searchParams.get("sessionId");
  const sessionHeader = req.headers["x-session-id"];
  const targetSessionId = requestedSessionId || querySessionId ||
    (typeof sessionHeader === "string" ? sessionHeader : undefined);
  const reqClientMode = resolveClientMode(req);

  if (wsPath) {
    wsPath = (wsPath.startsWith("ssh:") || wsPath.startsWith("ssh://") || wsPath.startsWith("chain:"))
      ? wsPath
      : path.resolve(wsPath);
  }

  // A session ID is not sufficient authorization on its own. Bind lookups to
  // the requested client mode and workspace so cross-project IDs fail closed.
  if (targetSessionId) {
    for (const session of activeSessions.values()) {
      if (session.sessionId !== targetSessionId || session.clientMode !== reqClientMode) {
        continue;
      }

      if (wsPath && session.workspace.toLowerCase() !== wsPath.toLowerCase()) {
        continue;
      }

      session.lastActiveTime = Date.now();
      return session;
    }
    return null;
  }

  if (wsPath) {
    for (const session of activeSessions.values()) {
      if (session.clientMode === reqClientMode && session.workspace.toLowerCase() === wsPath.toLowerCase()) {
        session.lastActiveTime = Date.now();
        return session;
      }
    }
  }

  for (const session of activeSessions.values()) {
    if (session.clientMode === reqClientMode && session.isCliSession) {
      if (!wsPath || session.workspace.toLowerCase() === wsPath.toLowerCase()) {
        session.lastActiveTime = Date.now();
        return session;
      }
    }
  }

  return null;
}
function isRemoteWorkspaceTarget(p: string): boolean {
  return p.startsWith("ssh:") || p.startsWith("ssh://") || p.startsWith("chain:");
}

function getValidWorkspaceRoots(): string[] {
  const roots = new Set<string>([path.resolve(process.cwd())]);
  // A trusted directory explicitly approved in SuperAgent is a valid API workspace.
  // It is still scoped to this exact trusted root (or its children).
  const candidates: string[] = [lastActiveWorkspace, ...getTrustedDirectories()];
  for (const session of activeSessions.values()) {
    candidates.push(session.workspace);
    const agentWs = (session.agent as any)?.workingDirectory;
    if (typeof agentWs === "string") candidates.push(agentWs);
  }
  for (const c of candidates) {
    if (c && !isRemoteWorkspaceTarget(c)) {
      roots.add(path.resolve(c));
    }
  }
  return Array.from(roots);
}

export function resolveWorkspacePath(req: http.IncomingMessage): string | null {
  const parsedUrl = new URL(req.url || "", `http://${req.headers.host || "localhost"}`);
  const headerWs = req.headers["x-workspace-path"] as string;
  const paramWs = parsedUrl.searchParams.get("workspace");
  const supplied = headerWs || paramWs;
  if (supplied) {
    if (isRemoteWorkspaceTarget(supplied)) return supplied;
    const resolved = path.resolve(supplied);
    const validRoots = getValidWorkspaceRoots();
    if (!validRoots.some((root) => isPathInsideOrEqual(root, resolved))
      || ((parsedUrl.pathname.startsWith("/api/studio") || parsedUrl.pathname.startsWith("/api/motion")) && !isCanonicalMotionWorkspaceAllowed(resolved, validRoots))) {
      logToSuperAgentServerFile(`[Security] Rejected workspace path outside trusted real roots: ${resolved}`);
      return null;
    }
    return resolved;
  }

  const session = resolveSession(req);
  return session ? session.workspace : lastActiveWorkspace;
}

export function registerCliAgent(agent: Agent, workspace: string, mode: "single" | "multi", clientMode: ClientMode = "tline") {
  const targetWorkspace = (workspace.startsWith("ssh:") || workspace.startsWith("ssh://") || workspace.startsWith("chain:"))
    ? workspace
    : path.resolve(workspace);
  activeSessions.set(`${clientMode}:${targetWorkspace}:cli`, {
    agent,
    workspace: targetWorkspace,
    mode,
    clientMode,
    sessionId: generateSessionId(),
    isCliSession: true
  });
  lastActiveWorkspace = targetWorkspace;
}


interface BrowserInstance {
  res: http.ServerResponse;
  clientId: string;
  windowId: string;
  tabTitle: string;
  tabUrl: string;
  profileName: string;
  source: string;
  lastActive: number;
}
const sseClients = new Set<http.ServerResponse>();
const sseClientContexts = new Map<http.ServerResponse, { sessionId?: string; workspace?: string }>();
const browserInstances = new Map<string, BrowserInstance>();

interface PendingPrompt<T> {
  resolve: (value: T) => void;
  ownerAgent?: Agent;
  sessionId?: string;
  workspace: string;
}

const pendingPermissions = new Map<string, PendingPrompt<boolean | "session">>();
const pendingQuestions = new Map<string, PendingPrompt<any>>();
const pendingBrowserControls = new Map<string, {
  resolve: (val: string) => void;
  reject: (err: any) => void;
  controlToken: string;
}>();

/** Max time to wait for the sidepanel client to answer a browser-control request.
 *  Without this, a dead-but-connected sidepanel would hang the caller forever. */
const BROWSER_CONTROL_TIMEOUT_MS = 15000;

function executeBrowserControlOnClient(action: string, target: string, value?: string, instanceId?: string): Promise<string> {
  return new Promise<string>((resolve, reject) => {
    const controlId = crypto.randomUUID();
    const controlToken = crypto.randomBytes(32).toString("base64url");
    // Fail-fast: never leave the caller hanging if the sidepanel never answers.
    const timer = setTimeout(() => {
      if (pendingBrowserControls.delete(controlId)) {
        reject(new Error(
          `Timed out after ${BROWSER_CONTROL_TIMEOUT_MS / 1000}s waiting for the Chrome extension sidepanel to respond to '${action}'. ` +
          `The Superagent Chrome Extension must be installed and connected on the target Chrome browser, with its sidepanel open and responsive.`
        ));
      }
    }, BROWSER_CONTROL_TIMEOUT_MS);
    pendingBrowserControls.set(controlId, {
      resolve: (val: string) => { clearTimeout(timer); resolve(val); },
      reject: (err: any) => { clearTimeout(timer); reject(err); },
      controlToken,
    });

    const event = {
      type: "browser_control_required",
      controlId,
      controlToken,
      action,
      target,
      value: value ?? ""
    };

    // Never broadcast executable browser commands to unrelated sessions or tabs.
    // Ambiguous multi-client dispatch must fail closed until the caller selects an instance.
    const live = [...browserInstances.entries()].filter(([, inst]) =>
      inst.res && !inst.res.destroyed && !inst.res.writableEnded);
    const match = instanceId
      ? live.find(([key]) => key === instanceId)
      : live.length === 1 ? live[0] : undefined;
    if (!match) {
      clearTimeout(timer);
      pendingBrowserControls.delete(controlId);
      reject(new Error(instanceId
        ? "Requested Chrome extension instance is not connected."
        : "Browser control needs exactly one connected extension; select an instance explicitly."));
      return;
    }
    const [key, inst] = match;
    try {
      inst.res.write(`data: ${JSON.stringify(event)}\n\n`);
      inst.lastActive = Date.now();
    } catch (err) {
      browserInstances.delete(key);
      clearTimeout(timer);
      pendingBrowserControls.delete(controlId);
      reject(new Error(`Failed to send browser control event: ${err}`));
    }
  });
}

setBrowserControlHandler((action, target, value, instanceId) => {
  if (action === "list_instances") {
    const list = Array.from(browserInstances.entries()).map(([key, inst]) => ({
      instanceId: key,
      clientId: inst.clientId,
      windowId: inst.windowId,
      profileName: inst.profileName,
      tabTitle: inst.tabTitle,
      tabUrl: inst.tabUrl,
      lastActive: new Date(inst.lastActive).toISOString()
    }));
    return Promise.resolve(JSON.stringify(list, null, 2));
  }
  return executeBrowserControlOnClient(action, target, value, instanceId);
});

const chatEventReplay = new SessionEventReplay();
function broadcastEvent(event: any) {
  // Normalize SSE event types for client backward compatibility
  const normalizedEvent = { ...event };
  if (event?.type === "superagent-sessions-changed") {
    normalizedEvent.event = "sessions_changed";
  }

  const sensitiveTypes = new Set([
    "agent_event", "permission_required", "question_required",
    "plan_approval_required", "tool_progress", "browser_control_required",
    "tline_bridge_sync", "error", "subagents_update", "superagents_update",
    "chat_turn_status", "chat_replay_gap",
  ]);
  if (sensitiveTypes.has(normalizedEvent.type) &&
      !normalizedEvent.sessionId && !normalizedEvent.workspace) {
    return; // Fail closed: no recipient context for a sensitive stream.
  }
  // Event journal is T-Line-only and strictly bound to a server-owned active
  // workspace/session pair. Never persist raw event payloads or capability tokens.
  if (typeof normalizedEvent.sessionId === "string" &&
      typeof normalizedEvent.workspace === "string") {
    const owner = [...activeSessions.values()].find(session =>
      session.clientMode === "tline" &&
      session.sessionId === normalizedEvent.sessionId &&
      session.workspace.toLowerCase() === normalizedEvent.workspace.toLowerCase());
    if (owner) {
      // Legacy live subscriptions may fall back to workspace-only ownership.
      // Never persist a subagent from another session into this journal.
      const journalEnvelope = normalizedEvent.type === "subagents_update"
        ? { ...normalizedEvent, subagents: (Array.isArray(normalizedEvent.subagents)
          ? normalizedEvent.subagents : []).filter((sa: any) => {
          const inst = typeof sa?.id === "string" ? subagentInstances.get(sa.id) : undefined;
          return !!inst && (inst.parentAgent === owner.agent ||
            inst.agent?.sessionId === owner.sessionId);
        }) } : normalizedEvent;
      const scope = { sessionId: owner.sessionId, workspace: owner.workspace };
      for (const item of projectAgentTimelineEnvelope(journalEnvelope)) {
        recordAgentTimeline(scope, item);
      }
    }
  }
  const eventJson = JSON.stringify(normalizedEvent);
  let data = `data: ${eventJson}\n\n`;
  if (typeof normalizedEvent.sessionId === "string") {
    try {
      const id = appendChatEvent(normalizedEvent.sessionId, eventJson);
      data = id === null ? data : `id: ${id}\n${data}`;
    } catch (error) {
      // Temporary journal failure must not silently drop live chat progress.
      data = chatEventReplay.publish(normalizedEvent.sessionId, eventJson);
      console.warn("[chat] event journal unavailable; using bounded in-memory replay");
    }
  }
  
  // Log event to the server debug log file
  // Log metadata only; event payloads can include secret browser capabilities.
  logToSuperAgentServerFile(`[Broadcast Event] type=${String(normalizedEvent.type || "unknown")} scoped=${Boolean(normalizedEvent.sessionId || normalizedEvent.workspace)}`);
  
  if (process.env.LOG_STREAM_RESPONSE === 'true') {
    if (normalizedEvent?.event?.type === 'text_delta') {
      process.stdout.write(normalizedEvent.event.text || normalizedEvent.event.delta || '');
    } else if (normalizedEvent?.event?.type === 'message') {
      const sub = normalizedEvent.event;
      const contentStr = typeof sub.content === 'string' ? sub.content : JSON.stringify(sub.content);
      console.log(`\n[SuperAgent][Stream Message] [${sub.role || 'assistant'}]: ${contentStr}`);
    } else if (normalizedEvent?.event?.type) {
      console.log(`\n[SuperAgent][Stream Event] [${normalizedEvent.event.type}]`, JSON.stringify(normalizedEvent.event));
    } else {
      console.log(`\n[SuperAgent][Stream Event]`, JSON.stringify(normalizedEvent));
    }
  }
  for (const client of sseClients) {
    const context = sseClientContexts.get(client);
    if (!shouldDeliverEventToClient(normalizedEvent, context)) continue;

    try {
      client.write(data);
    } catch {
      sseClients.delete(client);
      sseClientContexts.delete(client);
    }
  }
}



function sendJSON(res: http.ServerResponse, status: number, data: any) {
  logToSuperAgentServerFile(`[Response] Status: ${status}`);
  res.writeHead(status, {
    "Content-Type": "application/json",
    ...buildCorsHeaders(res.req),
  });
  res.end(JSON.stringify(data));
}

function readBody(req: http.IncomingMessage): Promise<string> {
  const MAX_BODY_BYTES = 32 * 1024 * 1024;
  return new Promise((resolve, reject) => {
    let body = "";
    let size = 0;
    let failed = false;
    req.on("data", (chunk: Buffer) => {
      if (failed) return;
      size += Buffer.byteLength(chunk);
      if (size > MAX_BODY_BYTES) {
        failed = true;
        req.pause();
        reject(new Error("Request body too large"));
        return;
      }
      body += chunk.toString("utf8");
    });
    req.on("end", () => { if (!failed) resolve(body); });
    req.on("error", err => { if (!failed) reject(err); });
  });
}

function getSessionForAgent(agentRef?: Agent): AgentSession | undefined {
  if (!agentRef) return undefined;
  for (const session of activeSessions.values()) {
    if (session.agent === agentRef) return session;
  }
  return undefined;
}

// Global Agent Event Handlers
const onEvent = (event: AgentEvent, agentRef?: Agent) => {
  const session = getSessionForAgent(agentRef);
  const sessionId = session?.sessionId || agentRef?.sessionId;
  if (session?.sessionId && agentRef && agentRef.sessionId !== session.sessionId) {
    agentRef.sessionId = session.sessionId;
  }
  const workspace = session?.workspace || agentRef?.workingDirectory;
  const metadata = { ...(sessionId ? { sessionId } : {}), ...(workspace ? { workspace } : {}) };
  if (session) {
    session.lastActiveTime = Date.now();
    if (agentRef && session.clientMode === "tline") {
      bindTlineRootAgent(agentRef, { workspace: session.workspace, sessionId: session.sessionId });
    }
  }
  broadcastEvent({ type: "agent_event", event, ...metadata });
  // When agent finishes a turn and is waiting for plan approval, notify extension clients
  if (event.type === "done" && agentRef && agentRef.planState === "PLANNING_PENDING") {
    broadcastEvent({ type: "plan_approval_required", planState: "PLANNING_PENDING", ...metadata });
  }
};

// Subscribe to active tool output streaming and broadcast it to SSE clients
subscribeToActiveOutput((_output) => {
  // Legacy process-wide output lacks a session key. Agent-scoped events already
  // deliver progress; do not leak unscoped tool output to other workspaces.
});

// Subscribe to subagents/superagents completion notifications to broadcast and/or resume the agent
subscribeToSubagents(() => {
  const activeList = Array.from(subagentInstances.values());

  // Subagent results and prompts are private to the owning workspace/session.
  for (const session of activeSessions.values()) {
    const owned = activeList.filter((inst) => inst.parentAgent
      ? inst.parentAgent === session.agent
      : path.resolve(inst.agent.workingDirectory) === path.resolve(session.workspace));
    if (!owned.length) continue;
    broadcastEvent({
      type: "subagents_update",
      sessionId: session.sessionId,
      workspace: session.workspace,
      subagents: owned.map((inst) => ({
        id: inst.id,
        typeName: inst.typeName,
        role: inst.role,
        status: inst.status,
        result: inst.result,
        logs: inst.logs || [],
        prompt: inst.prompt,
        completedAt: inst.completedAt
      }))
    });
  }

  activeList.forEach((inst) => {
    if (inst.status === "completed" && inst.result && !(inst as any).notified) {
      (inst as any).notified = true;
      const msg = `🤖 [SUBAGENT NOTIFICATION]: Subagent ${inst.id} (${inst.role || inst.typeName}) has completed!\nReport Summary:\n${inst.result}`;
      
      // The matching session receives this notification below.

      for (const session of activeSessions.values()) {
        const isMatch = inst.parentAgent
          ? session.agent === inst.parentAgent
          : path.resolve(session.workspace) === path.resolve(inst.agent.workingDirectory);
        if (!isMatch) continue;
        broadcastEvent({
          type: "agent_event",
          event: { type: "system", content: msg },
          sessionId: session.sessionId,
          workspace: session.workspace,
        });
        if (!session.agent.isAgentRunning()) {
          broadcastEvent({
            type: "agent_event",
            event: { type: "text", content: `\n[SYSTEM TRIGGER] ${msg}\n` },
            sessionId: session.sessionId,
            workspace: session.workspace,
          });
          session.agent.sendMessage(msg).catch(err => {
            broadcastEvent({
              type: "error", message: err.message || String(err),
              sessionId: session.sessionId, workspace: session.workspace,
            });
          });
        }
      }
    }
  });
});

subscribeToSuperagents(() => {
  const activeList = Array.from(superagentInstances.values());
  activeList.forEach((inst) => {
    if (inst.status === "completed" && inst.result && !(inst as any).notified) {
      (inst as any).notified = true;
      const msg = `⚡ [SUPERAGENT NOTIFICATION]: Superagent ${inst.id} (${inst.role}) has completed!\nReport Summary:\n${inst.result}`;
      
      // Scoped delivery takes place in the session loop below.

      for (const session of activeSessions.values()) {
        const isMatch = inst.parentAgent
          ? session.agent === inst.parentAgent
          : path.resolve(session.workspace) === path.resolve(inst.agent.workingDirectory);
        if (!isMatch) continue;
        broadcastEvent({
          type: "agent_event",
          event: { type: "system", content: msg },
          sessionId: session.sessionId, workspace: session.workspace,
        });
        if (!session.agent.isAgentRunning()) {
          broadcastEvent({
            type: "agent_event",
            event: { type: "text", content: `\n[SYSTEM TRIGGER] ${msg}\n` },
            sessionId: session.sessionId, workspace: session.workspace,
          });
          session.agent.sendMessage(msg).catch(err => {
            broadcastEvent({
              type: "error", message: err.message || String(err),
              sessionId: session.sessionId, workspace: session.workspace,
            });
          });
        }
      }
    }
  });
});

function getPromptOwner(ownerAgent?: Agent): { sessionId?: string; workspace: string } {
  if (ownerAgent) {
    for (const session of activeSessions.values()) {
      if (session.agent === ownerAgent) {
        return { sessionId: session.sessionId, workspace: session.workspace };
      }
    }
    const agentWorkspace = (ownerAgent as any).workingDirectory;
    return {
      workspace: typeof agentWorkspace === "string" && agentWorkspace ? agentWorkspace : process.cwd(),
      sessionId: (ownerAgent as any).sessionId,
    };
  }

  // Global/subagent question handlers have no direct agent reference. Only associate
  // them when there is one unambiguous running session in the last active workspace.
  const candidates = [...activeSessions.values()].filter(session =>
    session.agent.isAgentRunning() &&
    session.workspace.toLowerCase() === lastActiveWorkspace.toLowerCase()
  );
  if (candidates.length === 1) {
    return { sessionId: candidates[0].sessionId, workspace: candidates[0].workspace };
  }
  return { workspace: lastActiveWorkspace };
}

const onPermission = (toolCall: any, description: string, ownerAgent: Agent) => {
  return new Promise<boolean | "session">((resolve) => {
    // Cryptographic uniqueness avoids colliding active permission prompts.
    const permissionId = crypto.randomUUID();
    const owner = getPromptOwner(ownerAgent);
    pendingPermissions.set(permissionId, { resolve, ownerAgent, ...owner });
    const session = [...activeSessions.values()].find(item =>
      item.agent === ownerAgent && item.clientMode === "tline" &&
      item.sessionId === owner.sessionId &&
      item.workspace.toLowerCase() === owner.workspace.toLowerCase());
    if (session) registerTlineApproval(permissionId, session.sessionId, session.workspace, () => {
      const pending = pendingPermissions.get(permissionId);
      if (pending && pending.ownerAgent === ownerAgent) {
        pendingPermissions.delete(permissionId);
        pending.resolve(false); // Expiration never becomes implicit approval.
        recordAgentTimeline({ workspace: session.workspace, sessionId: session.sessionId }, {
          kind: "permission_decided", actor: "main", status: "expired",
        });
      }
    });
    broadcastEvent({
      type: "permission_required",
      permissionId,
      toolCall,
      description,
      sessionId: owner.sessionId,
      workspace: owner.workspace,
    });
  });
};

const onQuestion = (
  question: any,
  options?: string[],
  isMultiSelect?: boolean,
  initialCheckedIndices?: number[],
  inputType?: string,
  ownerAgent?: Agent,
) => {
  return new Promise<any>((resolve) => {
    const owner = getPromptOwner(ownerAgent);
    if (!owner.sessionId) {
      resolve(null);
      return;
    }
    const questionId = Math.random().toString(36).substring(2, 9);
    pendingQuestions.set(questionId, { resolve, ownerAgent, ...owner });
    broadcastEvent({
      type: "question_required",
      questionId,
      question,
      options,
      isMultiSelect,
      initialCheckedIndices,
      inputType,
      sessionId: owner.sessionId,
      workspace: owner.workspace,
    });
  });
};

function isPortInUse(port: number): Promise<boolean> {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    socket.setTimeout(150);
    socket.once("connect", () => {
      socket.destroy();
      resolve(true);
    });
    socket.once("timeout", () => {
      socket.destroy();
      resolve(false);
    });
    socket.once("error", () => {
      socket.destroy();
      resolve(false);
    });
    socket.connect(port, "127.0.0.1");
  });
}

// Best-effort teardown of an idle harvested session: abort any in-flight agent
// work and kill background processes owned by its workspace before removal.
async function teardownIdleSession(session: AgentSession): Promise<void> {
  try {
    session.agent.abort();
  } catch {}
  try {
    const { backgroundTasks, isTaskInWorkspace } = await import("./core/tools/state.js");
    const { killProcessTree } = await import("./core/tools/shellTools.js");
    for (const [id, task] of backgroundTasks.entries()) {
      if (isTaskInWorkspace(task.cwd, session.workspace)) {
        try {
          killProcessTree(task.process.pid);
        } catch {}
        backgroundTasks.delete(id);
      }
    }
  } catch {}
}

export async function runServer(port: number, silent = false, defaultClientMode: ClientMode = "tline") {
  // Override console methods to write server logs to file
  const originalLog = console.log;
  const originalError = console.error;
  const originalWarn = console.warn;

  console.log = (...args: any[]) => {
    originalLog.apply(console, args);
    logToSuperAgentServerFile(`[INFO] ${args.map(a => typeof a === 'object' ? JSON.stringify(a) : String(a)).join(' ')}`);
  };

  console.error = (...args: any[]) => {
    originalError.apply(console, args);
    logToSuperAgentServerFile(`[ERROR] ${args.map(a => typeof a === 'object' ? JSON.stringify(a) : String(a)).join(' ')}`);
  };

  console.warn = (...args: any[]) => {
    originalWarn.apply(console, args);
    logToSuperAgentServerFile(`[WARN] ${args.map(a => typeof a === 'object' ? JSON.stringify(a) : String(a)).join(' ')}`);
  };

  logToSuperAgentServerFile(`Initializing SuperAgent Server on port ${port}...`);
  const serverAuthToken = ensureServerAuthToken();

  const inUse = await isPortInUse(port);
  if (inUse) {
    if (!silent) {
      console.warn(`\n⚠️ SuperAgent Server is already running on port ${port}.`);
      console.log(`💡 Exiting to prevent duplicate server instance.\n`);
      process.exit(0);
    }
    return null;
  }

  serverDefaultClientMode = defaultClientMode;
  registerQuestionHandler(onQuestion);
  // A supervised core restart adds a *new* worker while original sessions
  // remain active on their old workers. Never mark another generation's
  // running turns interrupted by applying global crash recovery here.
  try {
    pruneChatRuntimeLedger();
    if (process.env.SUPERAGENT_CORE_WORKER !== "1") {
      recoverInterruptedChatTurns();
    }
  } catch (err: any) {
    console.warn("[chat] turn recovery unavailable:", String(err?.message || err));
  }

  try {
    purgeEmptySessions(24);
  } catch {}

  try {
    const { bootstrapProcessSupervisorOnStartup } = await import("./core/process/processSupervisor.js");
    await bootstrapProcessSupervisorOnStartup({ workspaceRoot: process.cwd(), silent });
  } catch {}

  // Idle workspace session harvesting. Non-CLI sessions are reclaimed after
  // 30 min of inactivity; CLI-attached sessions get a longer 2h grace window
  // because they may simply be paused by a human at the terminal, but they
  // are still reaped eventually to keep the session map bounded in long-
  // running server deployments.
  const IDLE_TIMEOUT_MS = 30 * 60 * 1000;
  const CLI_IDLE_TIMEOUT_MS = 2 * 60 * 60 * 1000;
  const harvestTimer = setInterval(() => {
    const now = Date.now();
    for (const [key, session] of activeSessions.entries()) {
      if (session.agent.isAgentRunning()) continue;
      const lastActive = session.lastActiveTime || now;
      const timeout = session.isCliSession ? CLI_IDLE_TIMEOUT_MS : IDLE_TIMEOUT_MS;
      if (now - lastActive > timeout) {
        void teardownIdleSession(session).finally(() => {
          activeSessions.delete(key);
        });
      }
    }
  }, 5 * 60 * 1000);

  // Start the Python Vision Server in the background

  if (process.env.VITEST || process.env.NODE_ENV === "test") {
    const cleanup = () => {
      clearInterval(harvestTimer);
      try {
        closeHistoryDb();
      } catch {}
      try {
        const portServerInfoPath = path.join(getRootConfigDir(), `server-info-${port}.json`);
        if (fs.existsSync(portServerInfoPath)) {
          fs.unlinkSync(portServerInfoPath);
        }
      } catch {}
    };
    process.on("exit", cleanup);
    process.on("SIGINT", () => { cleanup(); process.exit(0); });
    process.on("SIGTERM", () => { cleanup(); process.exit(0); });
  } else {
    // Internal rolling generations share a single fixed-port vision helper.
    // They must not start competing Python services at port 8095.
    if (process.env.SUPERAGENT_CORE_WORKER !== "1" || process.env.SUPERAGENT_CORE_VISION_OWNER === "1") {
    try {
      const { execa } = await import("execa");
      const scriptPath = path.join(getPackageRootDir(), "scripts", "vision_server.py");
      visionServerProcess = execa("python", [scriptPath, "8095"], { windowsHide: true });
      if (!silent) {
        console.log("🚀 Starting Python UI-DETR-1 Vision Server on port 8095...");
      }

      visionServerProcess.catch((err: any) => {
        if (!silent) {
          console.error("[Vision Server Process Terminated/Failed]", err.message);
        }
      });
    } catch (err: any) {
      if (!silent) {
        console.error("Failed to spawn Python Vision Server:", err.message);
      }
    }
    }
    const cleanup = () => {
      clearInterval(harvestTimer);
      killVisionServerProcess();
      try {
        closeHistoryDb();
      } catch {}
      try {
        const portServerInfoPath = path.join(getRootConfigDir(), `server-info-${port}.json`);
        if (fs.existsSync(portServerInfoPath)) {
          fs.unlinkSync(portServerInfoPath);
        }
      } catch {}
    };
    process.on("exit", cleanup);
    process.on("SIGINT", () => { cleanup(); process.exit(0); });
    process.on("SIGTERM", () => { cleanup(); process.exit(0); });
  }
  const server = http.createServer(async (req, res) => {
    const parsedUrl = new URL(req.url || "", `http://${req.headers.host || "localhost"}`);
    const pathname = parsedUrl.pathname;

    // Private, loopback-only process inspection. The supervisor explicitly
    // blocks this route from the public listener before proxying.
    if (pathname === "/_core/internal/drain") {
      const secret = process.env.SUPERAGENT_CORE_INSPECT_TOKEN || "";
      const headerValue = req.headers["x-superagent-internal-token"];
      const provided = typeof headerValue === "string" ? headerValue : "";
      const a = Buffer.from(provided);
      const b = Buffer.from(secret);
      const authorized = process.env.SUPERAGENT_CORE_WORKER === "1" &&
        secret.length === 64 && req.method === "GET" &&
        (req.socket.remoteAddress === "127.0.0.1" || req.socket.remoteAddress === "::1") &&
        a.length === b.length && crypto.timingSafeEqual(a, b);
      if (!authorized) { res.writeHead(404); res.end(); return; }
      try {
        const { listSessions, listDetachedSessions } = await import("./core/tools/cliBridgeSession.js");
        const { getActiveRemoteTaskSnapshot } = await import("./core/remoteAgent/taskRunner.js");
        const { isMuseWatcherActive } = await import("./core/remoteAgent/museWatcherRegistry.js");
        const { daemonScheduler } = await import("./core/daemon/daemonScheduler.js");
        const report = evaluateCoreDrain(process.pid, process.env.SUPERAGENT_CORE_GENERATION_ID || "", {
          transportIsolated: process.env.SUPERAGENT_CORE_TRANSPORT_ISOLATED === "1",
          visionOwner: process.env.SUPERAGENT_CORE_VISION_OWNER === "1",
          metrics: {
            sessions: activeSessions.size,
            sseClients: sseClients.size,
            browserClients: browserInstances.size,
            pendingPrompts: pendingPermissions.size + pendingQuestions.size + pendingBrowserControls.size,
            backgroundTasks: [...backgroundTasks.values()].filter(t => !t.hasExited).length,
            // Conservative: even completed instance records can own references.
            agents: subagentInstances.size + superagentInstances.size,
            cliBridgeSessions: listSessions().filter(t => t.status !== "exited" && t.status !== "errored").length,
            detachedCliBridgeSessions: listDetachedSessions().length,
            scheduledJobs: scheduledJobs.size,
            remoteTasks: getActiveRemoteTaskSnapshot() ? 1 : 0,
            daemonRunning: daemonScheduler.isRunning() ? 1 : 0,
            museWatcher: isMuseWatcherActive() ? 1 : 0,
          },
        });
        res.writeHead(200, { "Content-Type": "application/json", "Cache-Control": "no-store" });
        res.end(JSON.stringify(report));
      } catch {
        res.writeHead(503, { "Content-Type": "application/json" });
        res.end(JSON.stringify({ safe: false, blockers: ["worker inspection failed"] }));
      }
      return;
    }

    logToSuperAgentServerFile(`[Request] ${req.method} ${pathname} (workspaceHeader=${Boolean(req.headers["x-workspace-path"])})`);

    // Auth gate for the HTTP API (OPTIONS preflight passes through)
    const isApiRoute = pathname === "/api" || pathname.startsWith("/api/");
    if (isApiRoute && req.method === "OPTIONS") {
      res.writeHead(204, buildCorsHeaders(req));
      res.end();
      return;
    }
    // Local-only invitation bootstrap uses per-session cryptographic capabilities,
    // never the long-lived Core server token. Reverse proxies are NOT authorized by
    // default; this exception is restricted to local socket and loopback Host.
    const takeoverLocal = (req.socket.remoteAddress === "127.0.0.1" ||
      req.socket.remoteAddress === "::1" || req.socket.remoteAddress === "::ffff:127.0.0.1") &&
      /^(?:127\.0\.0\.1|localhost)(?::\d+)?$/i.test(String(req.headers.host || ""));
    const localInvitationRoute = takeoverLocal && (
      (pathname === "/api/browser/takeover/ui" && req.method === "GET") ||
      (pathname === "/api/browser/takeover/redeem" && req.method === "POST") ||
      (pathname === "/api/browser/takeover/return" && req.method === "POST") ||
      (pathname === "/api/browser/takeover/cancel" && req.method === "POST") ||
      (pathname.startsWith("/api/browser/takeover/vendor/") && req.method === "GET")
    );
    if (isApiRoute && !localInvitationRoute && !isRequestAuthorized(req, parsedUrl)) {
      sendJSON(res, 401, { error: "Unauthorized" });
      return;
    }

    // Resolve a request-local workspace mode; never mutate the process-global mode
    // while handling HTTP requests because multiple workspaces may run concurrently.
    const targetWorkspace = resolveWorkspacePath(req);
    if (targetWorkspace === null) {
      sendJSON(res, 403, { error: "Forbidden workspace" });
      return;
    }

    const { workspaceMode } = await import("./core/ssh/workspaceMode.js");
    const requestSshConfig =
      targetWorkspace && (targetWorkspace.startsWith("ssh:") || targetWorkspace.startsWith("ssh://"))
        ? workspaceMode.parseSshTarget(targetWorkspace) ?? undefined
        : undefined;

    // CORS preflight for non-API routes (none mutate state today)
    if (req.method === "OPTIONS") {
      res.writeHead(204, buildCorsHeaders(req));
      res.end();
      return;
    }

    const { workspaceChainManager } = await import("./core/workspace/WorkspaceChainManager.js");
    await workspaceChainManager.runWithRequestContext(() =>
      workspaceMode.runWithWorkspaceConfig(requestSshConfig, async () => {
        try {
          // Chain activation and route execution share request-local workspace and chain state.
          if (targetWorkspace?.startsWith("chain:")) {
            const chainId = targetWorkspace.substring(6);
            const activeChain = workspaceChainManager.getActiveChain(targetWorkspace);
            if (!activeChain || activeChain.id !== chainId) {
              await workspaceChainManager.activateChain(chainId, targetWorkspace);
            }
          }

          const handled = await handleServerRoute(req, res, pathname, parsedUrl, {
            activeSessions,
            lastActiveWorkspace,
            setLastActiveWorkspace: (ws: string) => { lastActiveWorkspace = ws; },
            isBrowseDialogOpen,
            setIsBrowseDialogOpen: (v: boolean) => { isBrowseDialogOpen = v; },
            serverDefaultClientMode,
            sseClients,
            sseClientContexts,
            browserInstances,
            pendingPermissions,
            pendingQuestions,
            pendingBrowserControls,
            replaySessionEvents: (res: http.ServerResponse, sessionId: string, cursor?: string) => {
              if (cursor === undefined) return;
              try {
                const replay = replayChatEvents(sessionId, cursor);
                if (replay.gap && !res.writableEnded) {
                  res.write(`data: ${JSON.stringify({ type: "chat_replay_gap", sessionId })}\n\n`);
                }
                for (const event of replay.events) {
                  if (!res.writableEnded) res.write(event);
                }
              } catch {
                for (const event of chatEventReplay.since(sessionId, cursor)) {
                  if (!res.writableEnded) res.write(event);
                }
              }
            },
            resolveSession,
            resolveWorkspacePath,
            resolveClientMode,
            createAgentForMode,
            broadcastEvent,
            sendJSON,
            readBody,
            executeBrowserControlOnClient,
            killVisionServerProcess
          });

          if (!handled) {
            sendJSON(res, 404, { error: "Not Found" });
          }
        } catch (err: any) {
          console.error("[SERVER ERROR]", err);
          logToSuperAgentServerFile(`[SERVER ROUTE ERROR] ${err?.stack || err?.message || String(err)}`);
          sendJSON(res, 500, { error: err.message || String(err) });
        }
      })
    );
  });

  server.on("error", (err: any) => {
    logToSuperAgentServerFile(`[SERVER SOCKET ERROR] ${err?.stack || err?.message || String(err)}`);
    if (!silent) {
      console.error("[Server Error]", err);
    }
  });

    server.on("upgrade", async (req, socket, head) => {
    const parsedUrl = new URL(req.url || "", `http://${req.headers.host || "127.0.0.1"}`);
    if (parsedUrl.pathname === "/api/browser/takeover/ws") {
      try {
        const { getTakeoverWebsocketProxy } = await import("./core/browserTakeover/index.js");
        const proxy = getTakeoverWebsocketProxy();
        await proxy.handleUpgrade(req, socket as any, head, isRequestAuthorized);
      } catch {
        socket.destroy();
      }
      return;
    }
    socket.destroy();
  });

  server.listen(port, '127.0.0.1', () => {
    // T-Line's SuperAgent REST core uses this same startup path. Start only
    // the isolated shared-model watchdog; never touch T-Line/MCP/tunnels.
    if(process.env.SUPERAGENT_CORE_WORKER!=="1") {
      void import("./core/senopatiLifecycle.js")
        .then(({scheduleSenopatiLifecycle})=>scheduleSenopatiLifecycle())
        .catch(()=>{});
    }
    // The supervisor owns public auth metadata; private workers must not
    // overwrite shared server-info or invalidate existing client tokens.
    if (process.env.SUPERAGENT_CORE_WORKER !== "1") {
    try {
      const serverInfoPath = path.join(getRootConfigDir(), "server-info.json");
      const portServerInfoPath = path.join(getRootConfigDir(), `server-info-${port}.json`);
      const infoPayload = JSON.stringify({
        port,
        pid: process.pid,
        authToken: serverAuthToken,
        startedAt: Date.now()
      }, null, 2);
      // Atomic replace with best-effort owner-only mode; clients must
      // never observe a partially written token during restart.
      for (const destination of [serverInfoPath, portServerInfoPath]) {
        const pending = destination + "." + process.pid + ".tmp";
        try {
          fs.writeFileSync(pending, infoPayload, { encoding: "utf-8", mode: 0o600 });
          fs.renameSync(pending, destination);
          try { fs.chmodSync(destination, 0o600); } catch { /* Windows ACL may differ */ }
        } finally {
          try { fs.rmSync(pending, { force: true }); } catch {}
        }
      }
    } catch {}
    }
    // Never expose bearer credentials in persisted diagnostic logs.
    logToSuperAgentServerFile('[SERVER] Auth token initialized (redacted).');
    if (!silent) {
      console.log(`\n🚀 SuperAgent Server v${getSuperAgentVersion()} is running at http://localhost:${port}`);
      console.log(`💡 Mode: REST API & Server-Sent Events (SSE)`);
      console.log(`🎯 Default Client Mode: ${serverDefaultClientMode}`);
      console.log(`📂 Current Workspace: ${lastActiveWorkspace}`);
      console.log('[SERVER] Auth token saved to protected server-info (redacted).');
      console.log("💡 API clients should authenticate with Authorization: Bearer or x-auth-token headers. SSE uses authenticated fetch.\n");
    }
  });

  // Start the Chrome Remote WSS bridge silently in the background if not in a test environment
  if (!process.env.VITEST && process.env.NODE_ENV !== "test" && process.env.SUPERAGENT_CORE_WORKER !== "1") {
    try {
      const { ensureRemoteChromeBridge } = await import("./core/tools/remoteChromeBridge.js");
      ensureRemoteChromeBridge().catch(() => {});
    } catch {}
  }

  return server;
}
